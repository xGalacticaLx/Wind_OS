﻿function color1() {
    document.body.style.backgroundColor = "#4285f4";
}
function color2() {
    document.body.style.backgroundColor = "#34a853";
}
function color3() {
    document.body.style.backgroundColor = "#F57F17";
}
function color4() {
    document.body.style.backgroundColor = "#ea4335";
}